﻿using Bergs.Pxc.Pxcoiexn.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bergs.Pxc.ExemploUtilizacaoMenu
{
    class Program
    {
        static void Main(string[] args)
        {
            List<String> lista = new List<string>();
            lista.Add("Turma 2013");
            Menu menu = new Menu(
                new ItemMenu[] {
                new ItemMenu( new KeyValuePair<int,string>(1, "Elipse"), IncluirElipse, true),
                new ItemMenu( new KeyValuePair<int,string>(2, "Círculo"), IncluirCirculo, false),
                new ItemMenu( new KeyValuePair<int,string>(3, "Retângulo"), AlgumaCoisaRetangulo, false),
                new ItemMenu( new KeyValuePair<int,string>(4, "Quadrado"), MetodoQuadrado, false, false),
                new ItemMenu( new KeyValuePair<int,string>(5, "Sem nada no método"), null, true),
                new ItemMenu( new KeyValuePair<int,string>(6, "Exibir lista"), ExibirLista, false),
                new ItemMenu( new KeyValuePair<int,string>(0, "Sair"), null, true)
                }, lista);
            Int32 op = Tela.ControlaMenu("Figura Geométrica", menu);
            Console.WriteLine("Opção de saída = {0}", op);
            Console.ReadKey();
        }

        private static void ExibirLista(object parametro)
        {
            List<String> lista = (List<String>)parametro;
            Console.WriteLine("Exibindo a lista:");
            /*foreach (String item in lista)
            {
                Console.WriteLine(item);
            }*/
            CabecalhoLista[] cabecalho = new CabecalhoLista[2];
            cabecalho[0] = new CabecalhoLista("Conteúdo", CabecalhoLista.AlinhamentoCelula.Centralizado);
            cabecalho[1] = new CabecalhoLista("Outra coluna", CabecalhoLista.AlinhamentoCelula.Direita);
            List<LinhaLista> registros = new List<LinhaLista>();
            foreach (String item in lista)
            {
                //Console.WriteLine(item);
                LinhaLista registro = new LinhaLista();
                registro.Celulas.Add(item);
                registro.Celulas.Add("não sei");
                registros.Add(registro);
            }
            Tela.ImprimeLista("Exibindo a lista", cabecalho, registros, 15);
        }

        private static void MetodoQuadrado(object parametro)
        {
            List<String> lista = (List<String>)parametro;
            lista.Add("A melhor de todas");
            Console.WriteLine("Método do quadrado");
            Console.ReadKey();
        }

        private static void AlgumaCoisaRetangulo(object parametro)
        {
            throw new NotImplementedException();
        }

        private static void IncluirCirculo(object parametro)
        {
            throw new NotImplementedException();
        }

        private static void IncluirElipse(object parametro)
        {
            Console.WriteLine("Método da elipse");
        }
    }
}
